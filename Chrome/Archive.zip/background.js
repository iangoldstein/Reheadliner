chrome.runtime.onInstalled.addListener(() => {
  console.log('Reheadliner extension installed.');
});
